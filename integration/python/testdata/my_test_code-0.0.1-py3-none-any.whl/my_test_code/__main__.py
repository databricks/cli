"""
The entry point of the Python Wheel
"""

import sys
import os
import json


def main():
    out = {"PYTHONPATH": sys.path, "CWD": os.getcwd()}
    json_object = json.dumps(out, indent=4)
    print(json_object)


if __name__ == '__main__':
    main()
