"""Generate Lakeflow integration definitions from Python Operator entry points."""

import argparse
import importlib
import inspect
import json
import math
import pkgutil
from collections.abc import Callable
from enum import Enum
from pathlib import Path
from types import ModuleType
from typing import Annotated, Optional, Union, get_args, get_origin, get_type_hints

from databricks.lakeflow.integrations.shared._integration import get_integration_metadata
from databricks.lakeflow.integrations.shared._parameters import HttpConnectionFilter, HttpUcConnectionParameter
from databricks.lakeflow.integrations.shared._paramtypes import _SUPPORTED_PARAM_TYPES, _unwrap_optional

_SCHEMA_VERSION = "lakeflow-integration-v0.1.0"

_EntryPoint = Union[type, Callable]

# *args/**kwargs have no stable name to bind a widget to, and positional-only params
# cannot be passed by keyword (how the operator injects values), so none can be fields.
_UNSUPPORTED_PARAMETER_KINDS = frozenset(
    {
        inspect.Parameter.VAR_POSITIONAL,
        inspect.Parameter.VAR_KEYWORD,
        inspect.Parameter.POSITIONAL_ONLY,
    }
)


def _generate(package_module_name: str, environment: dict) -> list[dict]:
    """Return an integration definition for every entry point in the package.

    Definitions are ordered by their ``main`` entry point for deterministic
    output. ``environment`` is copied into every definition.
    """
    return [_build_definition(obj, environment) for obj in _discover_entry_points(package_module_name)]


def _discover_entry_points(package_module_name: str) -> list[_EntryPoint]:
    """Import the package recursively and collect its ``@integration`` entry points.

    Results are deduplicated by entry point name and sorted by it.
    """
    package = importlib.import_module(package_module_name)

    entry_points: dict[str, _EntryPoint] = {}
    for module in _load_modules(package):
        for _name, member in inspect.getmembers(module):
            if _is_entry_point(member, module.__name__):
                entry_points[f"{member.__module__}.{member.__qualname__}"] = member

    return [entry_points[main] for main in sorted(entry_points)]


def _load_modules(package_module: ModuleType) -> list[ModuleType]:
    """Import ``package_module`` and all of its submodules recursively.

    Import errors propagate rather than being collected: this is a build-time
    tool, so failing loudly beats emitting a partial definition set.
    """
    spec = package_module.__spec__
    if spec is None:
        raise ValueError(f"Module '{package_module.__name__}' has no __spec__")

    module_names = []
    # A package with an __init__.py has an origin. A namespace package does not.
    if spec.origin:
        module_names.append(spec.name)

    if spec.submodule_search_locations:
        prefix = spec.name + "."
        for _finder, name, _is_pkg in pkgutil.walk_packages(spec.submodule_search_locations, prefix):
            module_names.append(name)

    # Sort for a deterministic import order.
    return [importlib.import_module(name) for name in sorted(set(module_names))]


def _is_entry_point(obj: object, module_name: str) -> bool:
    # Restrict to entry points physically defined in this module so one
    # imported into another module is not reported twice.
    if getattr(obj, "__module__", None) != module_name:
        return False
    return get_integration_metadata(obj) is not None


def _build_definition(obj: _EntryPoint, environment: dict) -> dict:
    """Build a single ``lakeflow-integration-v0.1.0`` definition for ``obj``.

    ``environment`` is copied in verbatim; the console requires it (and it must
    carry the wheel that provides ``main``), so it is not optional.
    """
    metadata = get_integration_metadata(obj)
    # Unreachable (discovery only yields tagged objects); raise not assert so it
    # survives `python -O`.
    if metadata is None:
        raise ValueError(f"{obj.__module__}.{obj.__qualname__} is not an @integration entry point")

    return {
        "schema": _SCHEMA_VERSION,
        "name": metadata.display_name,
        "description": metadata.description or _docstring(obj) or metadata.display_name,
        "main": f"{obj.__module__}.{obj.__qualname__}",
        "config": _build_config(obj),
        "environment": environment,
    }


def _build_environment(
    dependencies: list[str],
    environment_version: str,
    environment_key: Optional[str],
) -> dict:
    """Build the shared ``environment`` block from CLI inputs.

    The console requires ``environment`` on every definition, with at least one
    dependency (which must include the wheel providing ``main``) and an
    ``environment_version``. Both are required CLI args, so an environment-less
    or empty definition cannot be emitted. Key order matches the schema:
    ``environment_key``, ``environment_version``, ``dependencies``.
    """
    if not dependencies:
        raise ValueError("environment requires at least one --dependency (must include the wheel that provides main)")

    environment: dict = {}
    if environment_key is not None:
        environment["environment_key"] = environment_key
    environment["environment_version"] = environment_version
    environment["dependencies"] = dependencies
    return environment


def _build_config(obj: _EntryPoint) -> dict:
    """Build the ``config`` JSON Schema from the entry point's signature.

    Parameters without a default are listed under ``required``. Scalar and enum
    defaults are carried through (an enum default as its member name). Signatures
    that would produce a definition the runtime cannot bind (a required
    positional-only param, or a default that contradicts its parameter's type)
    are rejected here, so the mismatch surfaces at build time rather than on every
    invocation.
    """
    _reject_unbindable_positional_only(obj)

    properties: dict[str, dict] = {}
    required: list[str] = []

    annotations = _annotations(obj)
    for param in _config_parameters(obj):
        annotation = annotations.get(param.name, param.annotation)
        prop = _config_property(param.name, annotation)
        annotation, _ = _resolve_parameter_annotation(annotation)

        if param.default is inspect.Parameter.empty:
            required.append(param.name)
        elif isinstance(param.default, Enum):
            # Before _is_scalar so an int/str-backed enum still emits its member name.
            _reject_mismatched_enum_default(param.name, annotation, param.default)
            prop["default"] = param.default.name
        elif _is_scalar(param.default):
            _reject_mismatched_default(param.name, annotation, param.default)
            prop["default"] = param.default

        properties[param.name] = prop

    config: dict = {"type": "object", "properties": properties}
    if required:
        config["required"] = required
    return config


def _reject_unbindable_positional_only(obj: _EntryPoint) -> None:
    # A required positional-only param can't be bound (injected by keyword), so it is
    # dropped and every invocation crashes; reject at build. One with a default is fine.
    for param in _signature_parameters(obj):
        if param.kind is inspect.Parameter.POSITIONAL_ONLY and param.default is inspect.Parameter.empty:
            raise ValueError(
                f"Parameter {param.name}: positional-only parameters cannot be bound "
                f"(the operator injects values by keyword); add a default or make it keyword-accessible."
            )


def _reject_mismatched_default(name: str, annotation: object, default: object) -> None:
    # A scalar default is emitted verbatim, so it must match the bound type; otherwise
    # the console pre-fills a value its converter rejects at run time. Reject at build.
    resolved = _unwrap_optional(annotation)
    if resolved is inspect.Parameter.empty:
        if not isinstance(default, str):
            raise ValueError(
                f"Parameter {name}: an unannotated parameter binds as a string, but its "
                f"default {default!r} is not a string; add a type annotation."
            )
        return

    if isinstance(resolved, type) and not _default_matches_type(default, resolved):
        raise ValueError(
            f"Parameter {name}: default {default!r} does not match the annotated type '{resolved.__name__}'."
        )


def _reject_mismatched_enum_default(name: str, annotation: object, default: object) -> None:
    resolved = _unwrap_optional(annotation)
    if resolved is inspect.Parameter.empty:
        raise ValueError(
            f"Parameter {name}: an unannotated parameter binds as a string, but its "
            f"default {default!r} is an enum member; annotate it with the enum type."
        )
    if isinstance(resolved, type) and not isinstance(default, resolved):
        raise ValueError(
            f"Parameter {name}: default {default!r} does not match the annotated type '{resolved.__name__}'."
        )


def _default_matches_type(default: object, resolved_type: type) -> bool:
    # bool is a subclass of int, so match by identity. An int default is accepted for a
    # float param since JSON has one number type and the binder widens it.
    if resolved_type is bool:
        return isinstance(default, bool)
    if resolved_type is int:
        return isinstance(default, int) and not isinstance(default, bool)
    if resolved_type is float:
        return isinstance(default, (int, float)) and not isinstance(default, bool)
    return isinstance(default, resolved_type)


def _signature_parameters(obj: _EntryPoint) -> list[inspect.Parameter]:
    try:
        signature = inspect.signature(obj)
    except (ValueError, TypeError):
        # Builtins and some C-level types have no introspectable signature.
        return []

    return list(signature.parameters.values())


def _config_parameters(obj: _EntryPoint) -> list[inspect.Parameter]:
    return [param for param in _signature_parameters(obj) if param.kind not in _UNSUPPORTED_PARAMETER_KINDS]


def _annotations(obj: _EntryPoint) -> dict:
    # get_type_hints resolves deferred/forward-ref annotations; for a class they live
    # on __init__. Errors propagate: a build failure beats erroring on every bind.
    target = obj.__init__ if inspect.isclass(obj) else obj
    return get_type_hints(target, include_extras=True)


def _config_property(name: str, annotation: object) -> dict:
    # Schema types come from the same table the binder is keyed on, so the two cannot
    # diverge. An unsupported annotation is rejected here, not on every bind.
    annotation, connection_filters = _resolve_parameter_annotation(annotation)
    if annotation is inspect.Parameter.empty:
        annotation = str

    is_http_connection = isinstance(annotation, type) and issubclass(annotation, HttpUcConnectionParameter)
    if is_http_connection:
        if len(connection_filters) > 1:
            raise ValueError(f"Parameter {name}: only one HttpConnectionFilter is allowed")
        return _build_http_connection_property(connection_filters)
    if len(connection_filters) > 0:
        raise ValueError(f"Parameter {name}: HttpConnectionFilter requires HttpUcConnectionParameter")

    if isinstance(annotation, type) and issubclass(annotation, Enum):
        return {"type": "string"}

    schema_type = _SUPPORTED_PARAM_TYPES.get(annotation) if isinstance(annotation, type) else None
    if schema_type is None:
        raise ValueError(
            f"Parameter {name}: unsupported type '{annotation}', "
            f"only str, int, float, bool, list, dict, and enums are supported."
        )
    return {"type": schema_type}


def _build_http_connection_property(connection_filters: list[HttpConnectionFilter]) -> dict:
    ui = {"widget": "select_uc_connection", "connection_type": "HTTP"}
    if connection_filters:
        connection_filter = connection_filters[0]
        for key, value in (("host", connection_filter.host), ("base_path", connection_filter.base_path)):
            if value is not None:
                ui[key] = value
    return {"type": "string", "x-ui": ui}


def _resolve_parameter_annotation(annotation: object) -> tuple[object, list[HttpConnectionFilter]]:
    """Unwrap Annotated/Optional layers to the underlying type, collecting any HttpConnectionFilter metadata."""
    if get_origin(annotation) is Annotated:
        inner, *metadata = get_args(annotation)
        resolved, filters = _resolve_parameter_annotation(inner)
        return resolved, filters + [value for value in metadata if isinstance(value, HttpConnectionFilter)]
    resolved = _unwrap_optional(annotation)
    if resolved is not annotation:
        return _resolve_parameter_annotation(resolved)
    return annotation, []


def _docstring(obj: _EntryPoint) -> Optional[str]:
    # __doc__ directly, not inspect.getdoc, which would inherit the Sensor
    # protocol's docstring for an undocumented sensor.
    doc = obj.__doc__
    if doc:
        for line in inspect.cleandoc(doc).splitlines():
            stripped = line.strip()
            if stripped:
                return stripped
    return None


def _is_scalar(value: object) -> bool:
    # The JSON scalars the schema allows (bool subclasses int). NaN/inf are excluded:
    # json.dumps emits NaN/Infinity, which are neither valid JSON nor YAML.
    if isinstance(value, float):
        return math.isfinite(value)
    return isinstance(value, (str, int, bool))


def _write_definitions(
    package_module_name: str,
    output_dir: Path,
    environment: dict,
) -> list[Path]:
    """Write one ``<main>.yaml`` file per entry point into ``output_dir``.

    ``main`` is the entry point's unique dotted path, so it is a collision-free
    file name. The body is formatted JSON, a valid YAML subset. Returns the
    written paths, sorted.

    ``output_dir`` is treated as owned by this tool: any ``*.yaml`` left from a
    prior run whose entry point no longer exists is removed, so a deleted or
    renamed integration cannot linger and be picked up as live.
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    written = []
    for definition in _generate(package_module_name, environment):
        path = output_dir / f"{definition['main']}.yaml"
        path.write_text(json.dumps(definition, indent=2) + "\n")
        written.append(path)

    # Write first, then prune, so a mid-run failure never deletes a good file it
    # would have rewritten.
    _prune_stale_definitions(output_dir, keep=written)

    return sorted(written)


def _prune_stale_definitions(output_dir: Path, keep: list[Path]) -> None:
    # Remove any *.yaml this run did not write, so a deleted/renamed entry point leaves
    # no stale definition. Top-level only (glob, not rglob), matching what we emit.
    current = set(keep)
    for existing in output_dir.glob("*.yaml"):
        if existing not in current:
            existing.unlink()


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--package-module",
        required=True,
        help="Dotted name of the package to load recursively, e.g. 'my_pkg'.",
    )
    parser.add_argument(
        "--output-dir",
        required=True,
        help="Directory to write one '<main>.yaml' file per sensor into.",
    )
    parser.add_argument(
        "--dependency",
        action="append",
        default=[],
        dest="dependencies",
        required=True,
        metavar="SPEC",
        help="pip-style dependency or workspace .whl path for the environment "
        "block. Repeatable; must include the wheel that provides the entry points.",
    )
    parser.add_argument(
        "--environment-version",
        required=True,
        help="environment_version for the environment block, e.g. '5'.",
    )
    parser.add_argument(
        "--environment-key",
        help="environment_key for the environment block.",
    )
    args = parser.parse_args(argv)

    environment = _build_environment(
        dependencies=args.dependencies,
        environment_version=args.environment_version,
        environment_key=args.environment_key,
    )
    _write_definitions(args.package_module, Path(args.output_dir), environment)


if __name__ == "__main__":
    main()
