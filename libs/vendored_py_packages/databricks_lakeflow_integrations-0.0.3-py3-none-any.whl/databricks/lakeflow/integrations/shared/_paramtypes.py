"""Parameter-type contract shared by the runtime binder and the definition generator.

The generator (generate._config_property) and the binder (runtime._convert_parameter)
live in separate modules that must not import each other. The generator imports the
developer's entry-point module to introspect its signatures, and that import can fail
at build time, so it is kept off the runtime's dependency path. This leaf is the one
thing both sides read: the set of bindable parameter types and the JSON Schema type
each is advertised as. It imports only the standard library so neither side pulls in
the other through it.
"""

from types import UnionType
from typing import TypeAlias, Union, get_args, get_origin

# A resolved annotation: a plain type, a union (Optional[T]), or Parameter.empty.
ParameterAnnotation: TypeAlias = object

# Bindable parameter types mapped to the JSON Schema type the generator advertises; the
# runtime converter table is keyed on the same types (parity-tested). list/dict have no
# widget, so they bind via a pasted JSON string advertised as "string".
_SUPPORTED_PARAM_TYPES: dict[type, str] = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
    list: "string",
    dict: "string",
}


def _unwrap_optional(annotation: ParameterAnnotation) -> ParameterAnnotation:
    """Unwrap ``Optional[T]`` to its single non-None arm.

    Integration entry-point signatures are authored by the developer, so a
    parameter can be annotated ``Optional[int]`` / ``int | None`` (an optional
    widget with no default), and binds like its underlying ``T``. Matches the
    ``typing`` spelling (``Optional[T]``, ``Union[T, None]``) and PEP 604
    ``T | None``, which ``get_type_hints`` preserves as a ``types.UnionType``.
    """
    if get_origin(annotation) in (Union, UnionType):
        args = [arg for arg in get_args(annotation) if arg is not type(None)]
        if len(args) == 1:
            return args[0]
    return annotation
