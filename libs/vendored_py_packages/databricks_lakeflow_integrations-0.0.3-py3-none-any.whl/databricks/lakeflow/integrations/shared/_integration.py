import inspect
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Optional, TypeVar

from databricks.lakeflow.integrations.shared._api import Operator, Sensor

F = TypeVar("F", bound=Callable[..., Any])

_INTEGRATION_METADATA_ATTR = "_databricks_integration_metadata"


@dataclass(frozen=True, kw_only=True)
class IntegrationMetadata:
    display_name: str
    description: Optional[str] = None


def integration(
    *,
    display_name: str,
    description: Optional[str] = None,
) -> Callable[[F], F]:
    """Mark an Operator, Sensor, or function to appear as an integration.

    Example::

        @integration(display_name="Refresh view")
        def refresh_mv(view: str): ...

        @integration(display_name="Orders")
        class OrdersSensor(Sensor): ...
    """
    metadata = IntegrationMetadata(display_name=display_name, description=description)

    def decorate(target: F) -> F:
        _ensure_is_taggable(target)
        # Entry points are invoked synchronously, so an async def would return an
        # unawaited coroutine and falsely report success; reject it up front.
        if _is_async(target):
            raise TypeError("@integration cannot decorate an async entry point; entry points are invoked synchronously")
        setattr(target, _INTEGRATION_METADATA_ATTR, metadata)
        return target

    return decorate


def _ensure_is_taggable(target: object) -> None:
    is_integration_class = isinstance(target, type) and issubclass(target, (Operator, Sensor))
    if is_integration_class or inspect.isfunction(target):
        return
    received = target.__name__ if isinstance(target, type) else type(target).__name__
    raise TypeError(f"@integration can decorate only Operator or Sensor subclasses or functions, got {received}")


def _is_async(target: object) -> bool:
    if isinstance(target, type):
        methods = ("open", "poll", "close") if issubclass(target, Operator) else ("poll",)
        return any(inspect.iscoroutinefunction(getattr(target, method, None)) for method in methods)
    return inspect.iscoroutinefunction(target)


def get_integration_metadata(target: object) -> Optional[IntegrationMetadata]:
    """Return the entry point's metadata, or None if it is not tagged."""
    # __dict__ for a class, not getattr, so a subclass of a tagged Sensor does
    # not inherit the tag.
    if isinstance(target, type):
        metadata = target.__dict__.get(_INTEGRATION_METADATA_ATTR)
    else:
        metadata = getattr(target, _INTEGRATION_METADATA_ATTR, None)
    return metadata if isinstance(metadata, IntegrationMetadata) else None
