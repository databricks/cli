"""Public integration types that entry-point authors import and annotate with.

Context, Operator, PollResult, Sensor, and SensorResult sit below both the runtime binder (runtime.py)
and the definition generator (generate.py) so both can build on them without
depending on each other. Standard library only, so importing the package does
not pull in the binder.
"""

import datetime
import importlib
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Literal, Protocol, runtime_checkable


def _get_runtime_dbutils() -> Any:
    """Lazily resolve dbutils, which is only importable on a cluster."""
    return importlib.import_module("databricks.sdk.runtime").dbutils


@dataclass(frozen=True, kw_only=True)
class Context:
    """Carries the context of the job task run.

    It is passed to integration methods so they can correlate work with the run
    they belong to.

    Attributes:
        main: Fully qualified name of the task entry point.
        task_key: Key of the task within the job.
        job_run_id: Identifier of the job run.
        task_run_id: Identifier of the task run.
        job_id: Identifier of the job.
    """

    main: str
    task_key: str
    job_run_id: int
    task_run_id: int
    job_id: int

    def set_task_value(self, key: str, value: Any) -> None:
        """Persist state that must survive a defer boundary (e.g. an external id).

        Backed directly by job task values: readable by downstream tasks, and in
        a ForEach shared across concurrent iterations of the same task key.
        """
        _get_runtime_dbutils().jobs.taskValues.set(key=key, value=value)

    def get_task_value(self, key: str, default: Any = None) -> Any:
        """Read back state set earlier in this task run. Any of open/poll/close
        may read or write."""
        return _get_runtime_dbutils().jobs.taskValues.get(
            taskKey=self.task_key,
            key=key,
            default=default,
            debugValue=default,
        )


@dataclass(frozen=True)
class PollResult:
    """Returned by an integration's poll method to complete or defer the task.

    Deferring releases compute resources.
    """

    status: Literal["completed", "deferred"]
    defer_for: datetime.timedelta | None = None

    @classmethod
    def completed(cls) -> "PollResult":
        return cls(status="completed")

    @classmethod
    def deferred(cls, duration: datetime.timedelta) -> "PollResult":
        return cls(status="deferred", defer_for=duration)


# Keep the preview sensor API working while both shapes share a result type.
SensorResult = PollResult


@runtime_checkable
class Sensor(Protocol):
    """Polls a condition and returns a :class:`PollResult` saying whether the
    condition is met or the sensor should be deferred.
    """

    def poll(self, ctx: "Context") -> PollResult:
        """Check the status of the condition being polled.

        Args:
            ctx: Context of the enclosing job task run.

        Returns:
            :meth:`PollResult.completed` if the condition has been met, or
            :meth:`PollResult.deferred` if the sensor should be deferred.
        """
        ...


class Operator(ABC):
    """A long-running operation with an open/poll/close lifecycle.

    Deferring on polling releases compute, meaning that instance attributes do
    NOT persist between calls. Carry state with :meth:`Context.set_task_value`
    in open() and read it back with :meth:`Context.get_task_value` in poll()
    and close().
    """

    def open(self, ctx: Context) -> None:
        """Called at most once at the start, before the first poll.

        Often used to open external resources and persist any identifiers or
        handles via :meth:`Context.set_task_value`.

        Args:
            ctx: Context of the enclosing job task run.
        """

    @abstractmethod
    def poll(self, ctx: Context) -> PollResult:
        """Called repeatedly after open.

        Use to check whether work has completed or should be deferred.

        Args:
            ctx: Context of the enclosing job task run.

        Returns:
            :meth:`PollResult.completed` if the external work has finished, or
            :meth:`PollResult.deferred` to release compute and poll again later.
        """

    def close(self, ctx: Context) -> None:
        """Cleanup phase. Use to release or cancel any external work.

        Runs when the poll completes. Also called if a deferred poll is
        cancelled or errors out.

        May be called multiple times, so it must be idempotent.

        Args:
            ctx: Context of the enclosing job task run.
        """
