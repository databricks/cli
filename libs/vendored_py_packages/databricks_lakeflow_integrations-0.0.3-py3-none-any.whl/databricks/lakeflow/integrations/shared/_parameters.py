from dataclasses import dataclass


class HttpUcConnectionParameter(str):
    """The name of a UC HTTP connection."""


@dataclass(frozen=True, kw_only=True)
class HttpConnectionFilter:
    """Optional exact-match filters for the UC HTTP connection picker."""

    host: str | None = None
    base_path: str | None = None

    def __post_init__(self) -> None:
        if self.host is not None and (not isinstance(self.host, str) or not self.host):
            raise ValueError("HttpConnectionFilter host must be a non-empty string")
        if self.base_path is not None and (not isinstance(self.base_path, str) or not self.base_path):
            raise ValueError("HttpConnectionFilter base_path must be a non-empty string")
