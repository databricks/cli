import importlib
from importlib.metadata import PackageNotFoundError, version

from databricks.lakeflow.integrations.shared._api import Context, Operator, PollResult, Sensor, SensorResult
from databricks.lakeflow.integrations.shared._integration import IntegrationMetadata, integration
from databricks.lakeflow.integrations.shared._parameters import HttpConnectionFilter, HttpUcConnectionParameter

try:
    __version__ = version("databricks-lakeflow-integrations")
except PackageNotFoundError:
    # Imported from an uninstalled source tree, so no dist metadata exists.
    __version__ = "0.0.0+unknown"

__all__ = [
    "_entrypoint",
    "Context",
    "Operator",
    "PollResult",
    "Sensor",
    "SensorResult",
    "integration",
    "IntegrationMetadata",
    "HttpConnectionFilter",
    "HttpUcConnectionParameter",
]


def _entrypoint(ctx: dict):
    # Import the binder lazily so importing this package never pulls runtime into
    # a consumer's build closure, and dbutils (cluster-only) stays off that path.
    from databricks.sdk.runtime import dbutils

    runtime = importlib.import_module("databricks.lakeflow.integrations.runtime")
    bindings = dbutils.widgets.getAll()
    return runtime._run_function(bindings=bindings, ctx=ctx)
