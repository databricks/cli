import datetime
import importlib
import inspect
import json
import traceback
from collections.abc import Callable
from enum import Enum
from types import TracebackType
from typing import Optional, get_type_hints

from databricks.lakeflow.integrations.shared._api import Context, Operator, PollResult, Sensor, SensorResult
from databricks.lakeflow.integrations.shared._parameters import HttpUcConnectionParameter
from databricks.lakeflow.integrations.shared._paramtypes import ParameterAnnotation, _unwrap_optional

__all__ = [
    "Context",
    "Operator",
    "PollResult",
    "Sensor",
    "SensorResult",
    "_run_function",
]


class _Outcome(Enum):
    COMPLETED = "COMPLETED"
    DEFERRED = "DEFERRED"


class _ClosableState(Enum):
    OPENING = "OPENING"
    OPENED = "OPENED"
    CLOSING = "CLOSING"
    CLOSED = "CLOSED"
    INIT_FAILED = "INIT_FAILED"
    CLOSE_FAILED = "CLOSE_FAILED"


class _PythonOperatorClientMessage:
    MIME_TYPE = "application/vnd.databricks.pythonoperatortask+json"

    def __init__(
        self,
        outcome: _Outcome,
        deferred_duration_millis: Optional[int],
        closable_state: _ClosableState | None = None,
        error: Exception | None = None,
    ):
        self.payload: dict = {"outcome": outcome.name}
        if deferred_duration_millis is not None:
            self.payload["deferred_duration_millis"] = deferred_duration_millis
        if closable_state is not None:
            self.payload["closable_state"] = closable_state.name
        self._error = error
        self._error_traceback: TracebackType | None = error.__traceback__ if error is not None else None

    def raise_for_error(self) -> None:
        # The caller assigns this report before raising so a later REPL command can collect it.
        if self._error is not None:
            raise self._error.with_traceback(self._error_traceback)

    def _repr_mimebundle_(self, **kwargs):
        return {self.MIME_TYPE: json.dumps(self.payload)}, {}

    def __repr__(self):
        return f"PythonOperatorClientMessage({self.payload})"


def _run_function(bindings: dict[str, str], ctx: dict):
    context = _parse_context(ctx)
    closable_state = _parse_closable_state(ctx)
    main = context.main

    parameters = {k: v for k, v in bindings.items() if not k.startswith("__databricks")}

    try:
        # main is a string like "a.b.c.function". `rsplit` on a bare name (no dot)
        # would raise an unfriendly unpacking error, so reject that up front.
        if "." not in main:
            raise ValueError("main is not a valid qualified name")

        module_name, func_name = main.rsplit(".", 1)

        if not module_name or not func_name:
            raise ValueError("main is not a valid qualified name")

        module = importlib.import_module(module_name)
        obj = getattr(module, func_name, None)

        if obj is None:
            raise ValueError(f"Function {func_name} not found in module {module_name}")
    except Exception as error:
        if closable_state is _ClosableState.OPENING:
            return _completed_message(_ClosableState.INIT_FAILED, error=error)
        raise

    if inspect.isfunction(obj):
        if closable_state is _ClosableState.CLOSING:
            return _completed_message(_ClosableState.CLOSED)
        try:
            _run_callable(obj, parameters)
        except Exception as error:
            if closable_state is _ClosableState.OPENING:
                return _completed_message(_ClosableState.CLOSED, error=error)
            raise

        return _completed_message(_ClosableState.CLOSED if closable_state is not None else None)
    elif _is_operator_class(obj):
        if closable_state not in (
            _ClosableState.OPENING,
            _ClosableState.OPENED,
            _ClosableState.CLOSING,
            _ClosableState.CLOSED,
        ):
            raise ValueError(f"Operator lifecycle state is missing or invalid: {ctx.get('closable_state')!r}")
        try:
            instance = _run_callable(obj, parameters)
        except Exception as error:
            if closable_state is _ClosableState.OPENING:
                return _completed_message(_ClosableState.INIT_FAILED, error=error)
            raise
        return _run_operator(instance, context, closable_state)
    elif _is_sensor_class(obj):
        if closable_state is _ClosableState.CLOSING:
            return _completed_message(_ClosableState.CLOSED)
        try:
            instance = _run_callable(obj, parameters)

            if not isinstance(instance, Sensor):
                raise ValueError(f"{func_name} is not a Sensor")

            result = instance.poll(context)
            deferred_duration_millis = _validate_poll_result_and_get_deferred_millis(result)
        except Exception as error:
            if closable_state is _ClosableState.OPENING:
                return _completed_message(_ClosableState.CLOSED, error=error)
            raise

        return _client_message_from_result(
            result,
            deferred_duration_millis=deferred_duration_millis,
            closable_state=_ClosableState.CLOSED if closable_state is not None else None,
        )
    else:
        raise ValueError(f"{func_name} is not a function, Sensor, or Operator")


def _parse_closable_state(ctx: dict) -> _ClosableState | None:
    raw = ctx.get("closable_state")
    if raw is None:
        return None
    try:
        return _ClosableState[raw]
    except KeyError as error:
        raise ValueError(f"Unknown operator lifecycle state: {raw}") from error


def _run_operator(instance: Operator, context: Context, closable_state: _ClosableState) -> _PythonOperatorClientMessage:
    has_close = type(instance).close is not Operator.close
    # Without a close override, CLOSED only means no cleanup is owed, not that
    # polling shouldn't continue.
    if closable_state is _ClosableState.CLOSED and has_close:
        raise ValueError("Operator with close cannot poll after it has closed")
    if closable_state is _ClosableState.CLOSING:
        return _close_operator(instance, context)

    try:
        if closable_state is _ClosableState.OPENING:
            instance.open(context)
        result = instance.poll(context)
        deferred_duration_millis = _validate_poll_result_and_get_deferred_millis(result)
    except Exception as error:
        return _close_operator(instance, context, work_error=error)

    if result.status == "deferred":
        # Report CLOSED when no cleanup is owed, so the control plane need not
        # provision compute just to invoke the inherited no-op close().
        return _PythonOperatorClientMessage(
            outcome=_Outcome.DEFERRED,
            deferred_duration_millis=deferred_duration_millis,
            closable_state=_ClosableState.OPENED if has_close else _ClosableState.CLOSED,
        )
    return _close_operator(instance, context)


def _validate_poll_result_and_get_deferred_millis(result: PollResult) -> int | None:
    if not isinstance(result, PollResult):
        raise TypeError("poll must return PollResult")
    if result.status == "completed" and result.defer_for is None:
        return None
    if result.status == "deferred" and isinstance(result.defer_for, datetime.timedelta):
        duration_millis = int(result.defer_for.total_seconds() * 1000)
        if duration_millis > 0:
            return duration_millis
    raise ValueError("poll returned an invalid status or deferral duration")


def _close_operator(
    instance: Operator,
    context: Context,
    work_error: Exception | None = None,
) -> _PythonOperatorClientMessage:
    try:
        instance.close(context)
    except Exception as error:
        if work_error is not None:
            traceback.print_exception(error)
        return _completed_message(_ClosableState.CLOSE_FAILED, error=work_error if work_error is not None else error)
    return _completed_message(_ClosableState.CLOSED, error=work_error)


def _completed_message(
    closable_state: _ClosableState | None,
    error: Exception | None = None,
) -> _PythonOperatorClientMessage:
    return _PythonOperatorClientMessage(
        outcome=_Outcome.COMPLETED,
        deferred_duration_millis=None,
        closable_state=closable_state,
        error=error,
    )


def _parse_context(ctx: dict) -> Context:
    return Context(
        main=ctx["main"],
        task_key=ctx["task_key"],
        job_run_id=ctx["job_run_id"],
        task_run_id=ctx["task_run_id"],
        job_id=ctx["job_id"],
    )


def _client_message_from_result(
    result: SensorResult,
    deferred_duration_millis: int | None,
    closable_state: _ClosableState | None = None,
) -> _PythonOperatorClientMessage:
    if result.status == "completed":
        return _PythonOperatorClientMessage(
            outcome=_Outcome.COMPLETED,
            deferred_duration_millis=None,
            closable_state=closable_state,
        )
    else:
        return _PythonOperatorClientMessage(
            outcome=_Outcome.DEFERRED,
            deferred_duration_millis=deferred_duration_millis,
            closable_state=closable_state,
        )


def _is_sensor_class(obj: object) -> bool:
    return inspect.isclass(obj) and issubclass(obj, Sensor)


def _is_operator_class(obj: object) -> bool:
    return inspect.isclass(obj) and issubclass(obj, Operator)


def _run_callable(obj, parameters: dict[str, str]):
    signature = inspect.signature(obj)
    converted_kwargs: dict[str, object] = {}

    # inspect.signature exposes raw annotations (literal strings under PEP 563);
    # get_type_hints evaluates them to real types. For a class they live on __init__.
    hints_target = obj.__init__ if inspect.isclass(obj) else obj
    type_hints = get_type_hints(hints_target)

    has_kwargs = any(param.kind == inspect.Parameter.VAR_KEYWORD for param in signature.parameters.values())
    if has_kwargs:
        converted_kwargs = {**parameters}

    for param in signature.parameters.values():
        if param.kind in [
            inspect.Parameter.VAR_POSITIONAL,  # non-deterministic, don't pass anything
            inspect.Parameter.VAR_KEYWORD,  # already captured as kwargs
            inspect.Parameter.POSITIONAL_ONLY,  # this will result in error when we call the function
        ]:
            continue

        if param.kind in [
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        ]:
            if param.name in parameters:
                annotation = type_hints.get(param.name, param.annotation)
                converted_kwargs[param.name] = _convert_parameter(param.name, annotation, parameters[param.name])

    return obj(**converted_kwargs)


def _invalid_value(name: str, kind: str, value: str) -> ValueError:
    return ValueError(f"Parameter {name}: invalid {kind} value '{value}'")


# No annotation: pass the raw widget string through unchanged. Otherwise a
# plain `def fn(x, **kwargs)` would error before the user code ever runs.
def _convert_str(name: str, value: str) -> str:
    return value


def _convert_int(name: str, value: str) -> int:
    try:
        return int(value)
    except ValueError as e:
        raise _invalid_value(name, "int", value) from e


def _convert_float(name: str, value: str) -> float:
    try:
        return float(value)
    except ValueError as e:
        raise _invalid_value(name, "float", value) from e


def _convert_bool(name: str, value: str) -> bool:
    if value not in ["true", "false"]:
        raise _invalid_value(name, "boolean", value)
    return value == "true"


def _convert_list(name: str, value: str) -> list:
    try:
        result = json.loads(value)
    except json.JSONDecodeError as e:
        raise _invalid_value(name, "list", value) from e
    if not isinstance(result, list):
        raise _invalid_value(name, "list", value)
    return result


def _convert_dict(name: str, value: str) -> dict:
    try:
        result = json.loads(value)
    except json.JSONDecodeError as e:
        raise _invalid_value(name, "dict", value) from e
    if not isinstance(result, dict):
        raise _invalid_value(name, "dict", value)
    return result


def _convert_enum(name: str, enum_type: type[Enum], value: str) -> Enum:
    # The generator advertises an enum member by name, so bind it back by name.
    member = enum_type.__members__.get(value)
    if member is None:
        raise _invalid_value(name, enum_type.__name__, value)
    return member


# Keyed on the same types as the generator's schema-type table (parity-tested); enums
# are handled separately in _convert_parameter since each is its own subclass.
_CONVERTERS: dict[type, Callable[[str, str], object]] = {
    str: _convert_str,
    int: _convert_int,
    float: _convert_float,
    bool: _convert_bool,
    list: _convert_list,
    dict: _convert_dict,
}


def _convert_parameter(name: str, type_annotation: ParameterAnnotation, value: str):
    type_annotation = _unwrap_optional(type_annotation)
    # No annotation binds as a pass-through string, matching the generator.
    if type_annotation is inspect.Parameter.empty:
        type_annotation = str

    if isinstance(type_annotation, type) and issubclass(type_annotation, Enum):
        return _convert_enum(name, type_annotation, value)

    if isinstance(type_annotation, type) and issubclass(type_annotation, HttpUcConnectionParameter):
        return type_annotation(value)

    convert = _CONVERTERS.get(type_annotation) if isinstance(type_annotation, type) else None
    if convert is None:
        # TODO: support more types, including generics
        raise ValueError(
            f"Parameter {name}: unsupported type '{type_annotation}', "
            f"only str, int, float, bool, list, dict, and enums are supported."
        )
    return convert(name, value)
