import inspect
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Optional, TypeVar

from databricks.lakeflow.integrations._api import Sensor

F = TypeVar("F", bound=Callable[..., Any])

_INTEGRATION_METADATA_ATTR = "_lakeflow_integration_metadata"


@dataclass(frozen=True, kw_only=True)
class IntegrationMetadata:
    display_name: str
    description: Optional[str] = None


def integration(*, display_name: str, description: Optional[str] = None) -> Callable[[F], F]:
    """Mark a Sensor subclass or a function to appear as an integration.

    Example::

        @integration(display_name="Refresh view")
        def refresh_mv(view: str): ...

        @integration(display_name="Orders")
        class OrdersSensor(Sensor): ...
    """
    metadata = IntegrationMetadata(display_name=display_name, description=description)

    def decorate(target: F) -> F:
        is_sensor = isinstance(target, type) and issubclass(target, Sensor)
        if not (is_sensor or inspect.isfunction(target)):
            raise TypeError("@integration can decorate only Sensor subclasses or functions")
        setattr(target, _INTEGRATION_METADATA_ATTR, metadata)
        return target

    return decorate


def get_integration_metadata(target: object) -> Optional[IntegrationMetadata]:
    """Return the entry point's metadata, or None if it is not tagged."""
    # __dict__ for a class, not getattr, so a subclass of a tagged Sensor does
    # not inherit the tag.
    if isinstance(target, type):
        metadata = target.__dict__.get(_INTEGRATION_METADATA_ATTR)
    else:
        metadata = getattr(target, _INTEGRATION_METADATA_ATTR, None)
    return metadata if isinstance(metadata, IntegrationMetadata) else None
