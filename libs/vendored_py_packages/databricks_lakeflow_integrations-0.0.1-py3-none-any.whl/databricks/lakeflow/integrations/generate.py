"""Generate Lakeflow integration definitions from Python Operator entry points."""

import argparse
import importlib
import inspect
import json
import pkgutil
from collections.abc import Callable
from pathlib import Path
from types import ModuleType
from typing import Optional, Union, get_args, get_origin, get_type_hints

from databricks.lakeflow.integrations._integration import get_integration_metadata

_SCHEMA_VERSION = "lakeflow-integration-v0.1.0"

_EntryPoint = Union[type, Callable]

# Parameter kinds that cannot be surfaced as named config fields: *args and
# **kwargs have no stable name to bind a widget to, and positional-only params
# cannot be passed by keyword (which is how the operator injects values).
_UNSUPPORTED_PARAMETER_KINDS = frozenset(
    {
        inspect.Parameter.VAR_POSITIONAL,
        inspect.Parameter.VAR_KEYWORD,
        inspect.Parameter.POSITIONAL_ONLY,
    }
)


def _generate(package_module_name: str, environment: Optional[dict] = None) -> list[dict]:
    """Return an integration definition for every entry point in the package.

    Definitions are ordered by their ``main`` entry point for deterministic
    output. ``environment`` is copied into every definition (omitted when None).
    """
    return [_build_definition(obj, environment) for obj in _discover_entry_points(package_module_name)]


def _discover_entry_points(package_module_name: str) -> list[_EntryPoint]:
    """Import the package recursively and collect its ``@integration`` entry points.

    Results are deduplicated by entry point name and sorted by it.
    """
    package = importlib.import_module(package_module_name)

    entry_points: dict[str, _EntryPoint] = {}
    for module in _load_modules(package):
        for _name, member in inspect.getmembers(module):
            if _is_entry_point(member, module.__name__):
                entry_points[f"{member.__module__}.{member.__qualname__}"] = member

    return [entry_points[main] for main in sorted(entry_points)]


def _load_modules(package_module: ModuleType) -> list[ModuleType]:
    """Import ``package_module`` and all of its submodules recursively.

    Simplified from the reference loader: import errors propagate rather than
    being collected, since this is a build-time tool where failing loudly is
    preferable to silently emitting a partial definition set.
    """
    spec = package_module.__spec__
    if spec is None:
        raise ValueError(f"Module '{package_module.__name__}' has no __spec__")

    module_names = []
    # A package with an __init__.py has an origin; a namespace package does not.
    if spec.origin:
        module_names.append(spec.name)

    if spec.submodule_search_locations:
        prefix = spec.name + "."
        for _finder, name, _is_pkg in pkgutil.walk_packages(spec.submodule_search_locations, prefix):
            module_names.append(name)

    # Sort for a deterministic import order.
    return [importlib.import_module(name) for name in sorted(set(module_names))]


def _is_entry_point(obj: object, module_name: str) -> bool:
    # Restrict to entry points physically defined in this module so one
    # imported into another module is not reported twice.
    if getattr(obj, "__module__", None) != module_name:
        return False
    return get_integration_metadata(obj) is not None


def _build_definition(obj: _EntryPoint, environment: Optional[dict] = None) -> dict:
    """Build a single ``lakeflow-integration-v0.1.0`` definition for ``obj``.

    ``environment`` is copied in verbatim when provided, otherwise omitted.
    """
    metadata = get_integration_metadata(obj)
    assert metadata is not None  # discovery only yields tagged objects

    definition = {
        "schema": _SCHEMA_VERSION,
        "name": metadata.display_name,
        "description": metadata.description or _docstring(obj) or metadata.display_name,
        "main": f"{obj.__module__}.{obj.__qualname__}",
        "config": _build_config(obj),
    }
    if environment is not None:
        definition["environment"] = environment
    return definition


def _build_environment(
    dependencies: list[str],
    environment_version: Optional[str],
    environment_key: Optional[str],
) -> Optional[dict]:
    """Build the shared ``environment`` block from CLI inputs.

    Key order matches the schema: ``environment_key``, ``environment_version``,
    ``dependencies``. Returns None when no environment inputs were supplied, so
    the block is omitted rather than emitted empty.
    """
    if not dependencies and environment_version is None and environment_key is None:
        return None

    environment: dict = {}
    if environment_key is not None:
        environment["environment_key"] = environment_key
    if environment_version is not None:
        environment["environment_version"] = environment_version
    environment["dependencies"] = dependencies
    return environment


def _build_config(obj: _EntryPoint) -> dict:
    """Build the ``config`` JSON Schema from the entry point's signature.

    Parameters without a default are listed under ``required``; scalar defaults
    are carried through.
    """
    properties: dict[str, dict] = {}
    required: list[str] = []

    annotations = _annotations(obj)
    for param in _config_parameters(obj):
        annotation = annotations.get(param.name, param.annotation)
        prop = _config_property(annotation)

        if param.default is inspect.Parameter.empty:
            required.append(param.name)
        elif _is_scalar(param.default):
            prop["default"] = param.default

        properties[param.name] = prop

    config: dict = {"type": "object", "properties": properties}
    if required:
        config["required"] = required
    return config


def _config_parameters(obj: _EntryPoint) -> list[inspect.Parameter]:
    try:
        signature = inspect.signature(obj)
    except (ValueError, TypeError):
        # Builtins and some C-level types have no introspectable signature.
        return []

    return [param for param in signature.parameters.values() if param.kind not in _UNSUPPORTED_PARAMETER_KINDS]


def _annotations(obj: _EntryPoint) -> dict:
    # get_type_hints resolves deferred (PEP 563) / forward-reference annotations
    # against the module globals. For a class they live on __init__.
    target = obj.__init__ if inspect.isclass(obj) else obj
    try:
        return get_type_hints(target)
    except (NameError, TypeError):
        # Unresolvable forward reference: fall back to raw annotations rather
        # than aborting the run.
        return {}


def _config_property(annotation: object) -> dict:
    # int gets the number widget; every other type is emitted with only its JSON
    # Schema type, letting the UI pick its default control.
    annotation = _unwrap_optional(annotation)

    if annotation is int:
        return {"type": "integer", "x-ui": {"widget": "number"}}
    if annotation is float:
        return {"type": "number"}
    if annotation is bool:
        return {"type": "boolean"}
    return {"type": "string"}


def _unwrap_optional(annotation: object) -> object:
    # Optional[T] is Union[T, None]; unwrap the single non-None arm.
    if get_origin(annotation) is Union:
        args = [arg for arg in get_args(annotation) if arg is not type(None)]
        if len(args) == 1:
            return args[0]
    return annotation


def _docstring(obj: _EntryPoint) -> Optional[str]:
    # __doc__ directly, not inspect.getdoc, which would inherit the Sensor
    # protocol's docstring for an undocumented sensor.
    doc = obj.__doc__
    if doc:
        for line in inspect.cleandoc(doc).splitlines():
            stripped = line.strip()
            if stripped:
                return stripped
    return None


def _is_scalar(value: object) -> bool:
    # bool is a subclass of int; all four are JSON scalars the schema allows.
    return isinstance(value, (str, int, float, bool))


def _write_definitions(
    package_module_name: str,
    output_dir: Path,
    environment: Optional[dict] = None,
) -> list[Path]:
    """Write one ``<main>.yml`` file per entry point into ``output_dir``.

    ``main`` is the entry point's unique dotted path, so it is a collision-free
    file name. The body is formatted JSON, a valid YAML subset. Returns the
    written paths, sorted.
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    written = []
    for definition in _generate(package_module_name, environment):
        path = output_dir / f"{definition['main']}.yml"
        path.write_text(json.dumps(definition, indent=2) + "\n")
        written.append(path)
    return written


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--package-module",
        required=True,
        help="Dotted name of the package to load recursively, e.g. 'my_pkg'.",
    )
    parser.add_argument(
        "--output-dir",
        required=True,
        help="Directory to write the '<main>.yml' files into.",
    )
    parser.add_argument(
        "--dependency",
        action="append",
        default=[],
        dest="dependencies",
        metavar="SPEC",
        help="pip-style dependency or workspace .whl path for the environment "
        "block. Repeatable; must include the wheel that provides the entry points.",
    )
    parser.add_argument(
        "--environment-version",
        help="environment_version for the environment block, e.g. '5'.",
    )
    parser.add_argument(
        "--environment-key",
        help="environment_key for the environment block.",
    )
    args = parser.parse_args(argv)

    environment = _build_environment(
        dependencies=args.dependencies,
        environment_version=args.environment_version,
        environment_key=args.environment_key,
    )
    _write_definitions(args.package_module, Path(args.output_dir), environment)


if __name__ == "__main__":
    main()
