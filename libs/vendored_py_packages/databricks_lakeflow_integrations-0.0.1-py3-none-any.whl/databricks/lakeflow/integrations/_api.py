"""Core API types for Databricks Lakeflow integrations."""

import datetime
from dataclasses import dataclass
from typing import Literal, Protocol, runtime_checkable

__all__ = [
    "Context",
    "Sensor",
    "SensorResult",
]


@dataclass(frozen=True, kw_only=True)
class Context:
    """Carries the context of the job task run.

    It is passed to :meth:`Sensor.poll` so sensor implementations can correlate
    their polling with the run they belong to.

    Attributes:
        main: Fully qualified name of the task entry point.
        task_key: Key of the task within the job.
        job_run_id: Identifier of the job run.
        task_run_id: Identifier of the task run.
        job_id: Identifier of the job.
    """

    main: str
    task_key: str
    job_run_id: int
    task_run_id: int
    job_id: int


@dataclass(frozen=True)
class SensorResult:
    """
    SensorResult is returned by Sensor.poll method to indicate whether
    the sensor has completed or should be deferred. When the sensor is
    deferred, compute resources are released.
    """

    status: Literal["completed", "deferred"]
    defer_for: datetime.timedelta | None = None

    @classmethod
    def completed(cls) -> "SensorResult":
        return cls(status="completed")

    @classmethod
    def deferred(cls, duration: datetime.timedelta) -> "SensorResult":
        return cls(status="deferred", defer_for=duration)


@runtime_checkable
class Sensor(Protocol):
    """
    Sensor is responsible for polling a condition and returning a SensorResult
    indicating whether the condition has been met or if the sensor should be deferred.
    """

    def poll(self, ctx: "Context") -> SensorResult:
        """Check the status of the condition being polled.

        Args:
            ctx: Context of the enclosing job task run.

        Returns:
            :meth:`SensorResult.completed` if the condition has been met, or
            :meth:`SensorResult.deferred` if the sensor should be deferred.
        """
        ...
