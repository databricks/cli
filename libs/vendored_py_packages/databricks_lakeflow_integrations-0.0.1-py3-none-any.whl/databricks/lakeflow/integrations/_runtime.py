"""Runtime entry point for executing Lakeflow Python operator tasks."""

import inspect
import importlib
import json
from enum import Enum
from typing import Optional, get_type_hints

from databricks.lakeflow.integrations._api import Context, Sensor, SensorResult

__all__ = [
    "Context",
    "Sensor",
    "SensorResult",
    "_entrypoint",
    "_run_function",
]


def _entrypoint(ctx: dict):
    # `databricks.sdk.runtime` is only available inside the user's cluster
    # Python environment. Import lazily so this module can be imported (and
    # unit-tested) without the SDK present.
    from databricks.sdk.runtime import dbutils

    bindings = dbutils.widgets.getAll()
    return _run_function(bindings=bindings, ctx=ctx)


class _Outcome(Enum):
    COMPLETED = "COMPLETED"
    DEFERRED = "DEFERRED"


class _PythonOperatorClientMessage:
    MIME_TYPE = "application/vnd.databricks.pythonoperatortask+json"

    def __init__(self, outcome: _Outcome, deferred_duration_millis: Optional[int]):
        self.payload: dict = {"outcome": outcome.name}
        if deferred_duration_millis is not None:
            self.payload["deferred_duration_millis"] = deferred_duration_millis

    def _repr_mimebundle_(self, **kwargs):
        return {self.MIME_TYPE: json.dumps(self.payload)}, {}

    def __repr__(self):
        return f"PythonOperatorClientMessage({self.payload})"


def _run_function(bindings: dict[str, str], ctx: dict):
    context = _parse_context(ctx)
    main = context.main

    parameters = {k: v for k, v in bindings.items() if not k.startswith("__databricks")}

    # main is a string like "a.b.c.function". `rsplit` on a bare name (no dot)
    # would raise an unfriendly unpacking error, so reject that up front.
    if "." not in main:
        raise ValueError("main is not a valid qualified name")

    module_name, func_name = main.rsplit(".", 1)

    if not module_name or not func_name:
        raise ValueError("main is not a valid qualified name")

    module = importlib.import_module(module_name)
    obj = getattr(module, func_name, None)

    if obj is None:
        raise ValueError(f"Function {func_name} not found in module {module_name}")

    if inspect.isfunction(obj):
        _run_callable(obj, parameters)

        return _PythonOperatorClientMessage(
            outcome=_Outcome.COMPLETED,
            deferred_duration_millis=None,
        )
    elif _is_sensor_class(obj):
        instance = _run_callable(obj, parameters)

        if not isinstance(instance, Sensor):
            raise ValueError(f"{func_name} is not a Sensor")

        result = instance.poll(context)

        return _client_message_from_result(result)
    else:
        raise ValueError(f"{func_name} is not a function or Sensor")


def _parse_context(ctx: dict) -> Context:
    return Context(
        main=ctx["main"],
        task_key=ctx["task_key"],
        job_run_id=ctx["job_run_id"],
        task_run_id=ctx["task_run_id"],
        job_id=ctx["job_id"],
    )


def _client_message_from_result(result: SensorResult) -> _PythonOperatorClientMessage:
    if result.status == "completed":
        return _PythonOperatorClientMessage(
            outcome=_Outcome.COMPLETED,
            deferred_duration_millis=None,
        )
    else:
        deferred_duration_millis = None
        if result.defer_for:
            deferred_duration_millis = int(result.defer_for.total_seconds() * 1000)

        return _PythonOperatorClientMessage(
            outcome=_Outcome.DEFERRED,
            deferred_duration_millis=deferred_duration_millis,
        )


def _is_sensor_class(obj: object) -> bool:
    return inspect.isclass(obj) and issubclass(obj, Sensor)


def _run_callable(obj, parameters: dict[str, str]):
    signature = inspect.signature(obj)
    converted_kwargs: dict[str, object] = {}

    # `inspect.signature(...).parameters[i].annotation` returns the raw
    # `__annotations__` entry, which is a literal string under PEP 563
    # (`from __future__ import annotations`) or PEP 484 explicit forward
    # references. `typing.get_type_hints` evaluates those strings against
    # the callable's module globals to produce the actual type objects.
    # For classes, annotations live on `__init__`.
    hints_target = obj.__init__ if inspect.isclass(obj) else obj
    type_hints = get_type_hints(hints_target)

    has_kwargs = any(param.kind == inspect.Parameter.VAR_KEYWORD for param in signature.parameters.values())
    if has_kwargs:
        # capture all parameters as kwargs if signature has kwargs
        converted_kwargs = {**parameters}

    # inspect func signature and validate parameters
    for param in signature.parameters.values():
        if param.kind in [
            inspect.Parameter.VAR_POSITIONAL,  # non-deterministic, don't pass anything
            inspect.Parameter.VAR_KEYWORD,  # already captured as kwargs
            inspect.Parameter.POSITIONAL_ONLY,  # this will result in error when we call the function
        ]:
            continue

        if param.kind in [
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        ]:
            if param.name in parameters:
                annotation = type_hints.get(param.name, param.annotation)
                converted_kwargs[param.name] = _convert_parameter(param.name, annotation, parameters[param.name])

    return obj(**converted_kwargs)


def _convert_parameter(name: str, annotation, value: str):
    # No annotation: pass the raw widget string through unchanged. Otherwise a
    # plain `def fn(x, **kwargs)` would error before the user code ever runs.
    if annotation is inspect.Parameter.empty or annotation is str:
        return value
    if annotation is int:
        try:
            return int(value)
        except ValueError as e:
            raise ValueError(f"Parameter {name}: invalid int value '{value}'") from e
    if annotation is float:
        try:
            return float(value)
        except ValueError as e:
            raise ValueError(f"Parameter {name}: invalid float value '{value}'") from e
    if annotation is bool:
        if value not in ["true", "false"]:
            raise ValueError(f"Parameter {name}: invalid boolean value '{value}'")
        return value == "true"
    if annotation is list:
        result = json.loads(value)
        if not isinstance(result, list):
            raise ValueError(f"Parameter {name}: invalid list value '{value}'")
        return result
    if annotation is dict:
        result = json.loads(value)
        if not isinstance(result, dict):
            raise ValueError(f"Parameter {name}: invalid dict value '{value}'")
        return result

    # TODO: support more types, including generics

    raise ValueError(
        f"Parameter {name}: unsupported type '{annotation}',"
        f"only str, int, float, bool, list, and dict are supported."
    )
