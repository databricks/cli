import datetime
import json
from enum import Enum
from types import TracebackType
from typing import Optional

from databricks.lakeflow.integrations.runtime._tracebacks import render_user_frames_only
from databricks.lakeflow.integrations.shared._api import PollResult, SensorResult


class IntegrationKind(Enum):
    FUNCTION = "FUNCTION"
    SENSOR = "SENSOR"
    OPERATOR = "OPERATOR"


class Outcome(Enum):
    COMPLETED = "COMPLETED"
    DEFERRED = "DEFERRED"


class ClosableState(Enum):
    OPENING = "OPENING"
    OPENED = "OPENED"
    CLOSING = "CLOSING"
    CLOSED = "CLOSED"
    INIT_FAILED = "INIT_FAILED"
    CLOSE_FAILED = "CLOSE_FAILED"


class PythonOperatorClientMessage:
    MIME_TYPE = "application/vnd.databricks.pythonoperatortask+json"

    def __init__(
        self,
        outcome: Outcome,
        deferred_duration_millis: Optional[int],
        closable_state: ClosableState | None = None,
        error: Exception | None = None,
    ):
        self.payload: dict = {"outcome": outcome.name}
        if deferred_duration_millis is not None:
            self.payload["deferred_duration_millis"] = deferred_duration_millis
        if closable_state is not None:
            self.payload["closable_state"] = closable_state.name
        self._error = error
        self._error_traceback: TracebackType | None = error.__traceback__ if error is not None else None
        if error is not None:
            render_user_frames_only(error)

    def raise_for_error(self) -> None:
        # The caller assigns this report before raising so a later REPL command can collect it.
        if self._error is not None:
            raise self._error.with_traceback(self._error_traceback)

    def _repr_mimebundle_(self, **kwargs):
        return {self.MIME_TYPE: json.dumps(self.payload)}, {}

    def __repr__(self):
        return f"PythonOperatorClientMessage({self.payload})"


def completed_message(
    closable_state: ClosableState | None,
    error: Exception | None = None,
) -> PythonOperatorClientMessage:
    return PythonOperatorClientMessage(
        outcome=Outcome.COMPLETED,
        deferred_duration_millis=None,
        closable_state=closable_state,
        error=error,
    )


def client_message_from_result(
    result: SensorResult,
    deferred_duration_millis: int | None,
    closable_state: ClosableState | None = None,
) -> PythonOperatorClientMessage:
    if result.status == "completed":
        return PythonOperatorClientMessage(
            outcome=Outcome.COMPLETED,
            deferred_duration_millis=None,
            closable_state=closable_state,
        )
    else:
        return PythonOperatorClientMessage(
            outcome=Outcome.DEFERRED,
            deferred_duration_millis=deferred_duration_millis,
            closable_state=closable_state,
        )


def validate_poll_result_and_get_deferred_millis(result: PollResult) -> int | None:
    if not isinstance(result, PollResult):
        raise TypeError("poll must return PollResult")
    if result.status == "completed" and result.defer_for is None:
        return None
    if result.status == "deferred" and isinstance(result.defer_for, datetime.timedelta):
        duration_millis = int(result.defer_for.total_seconds() * 1000)
        if duration_millis > 0:
            return duration_millis
    raise ValueError("poll returned an invalid status or deferral duration")
