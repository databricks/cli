import inspect
import json
from collections.abc import Callable
from enum import Enum
from typing import cast, get_args, get_origin, get_type_hints

from databricks.lakeflow.integrations.shared._parameters import HttpUcConnectionParameter, TextAreaParameter
from databricks.lakeflow.integrations.shared._paramtypes import (
    _SUPPORTED_TYPES_DESCRIPTION,
    ParameterAnnotation,
    _is_collection_annotation,
    _supported_parameter_type,
    _unwrap_optional,
)


def invoke(obj, parameters: dict[str, str]):
    signature = inspect.signature(obj)
    converted_kwargs: dict[str, object] = {}

    hints_target = obj.__init__ if inspect.isclass(obj) else obj
    type_hints = get_type_hints(hints_target)

    has_kwargs = any(param.kind == inspect.Parameter.VAR_KEYWORD for param in signature.parameters.values())
    if has_kwargs:
        converted_kwargs = {**parameters}

    for param in signature.parameters.values():
        if param.kind in [
            inspect.Parameter.VAR_POSITIONAL,  # non-deterministic, don't pass anything
            inspect.Parameter.VAR_KEYWORD,  # already captured as kwargs
            inspect.Parameter.POSITIONAL_ONLY,  # this will result in error when we call the function
        ]:
            continue

        if param.kind in [
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        ]:
            # The console persists an unfilled optional field as an empty string.
            if parameters.get(param.name) == "" and param.default is not inspect.Parameter.empty:
                converted_kwargs.pop(param.name, None)
            elif param.name in parameters:
                annotation = type_hints.get(param.name, param.annotation)
                converted_kwargs[param.name] = _convert_parameter(param.name, annotation, parameters[param.name])

    return obj(**converted_kwargs)


def _convert_parameter(name: str, type_annotation: ParameterAnnotation, value: str):
    type_annotation = _unwrap_optional(type_annotation)
    if type_annotation is inspect.Parameter.empty:
        type_annotation = str

    if _is_collection_annotation(type_annotation):
        return _convert_collection(name, type_annotation, value)

    parameter_type = _supported_parameter_type(type_annotation)
    if parameter_type is None:
        raise ValueError(f"Parameter {name}: unsupported type '{type_annotation}', {_SUPPORTED_TYPES_DESCRIPTION}")
    convert = _CONVERTERS[parameter_type]
    return convert(name, cast(type, type_annotation), value)


def _convert_enum(name: str, enum_type: type[Enum], value: str) -> Enum:
    member = enum_type.__members__.get(value)
    if member is None:
        raise _invalid_value(name, enum_type.__name__, value)
    return member


def _convert_str(name: str, type_annotation: type[str], value: str) -> str:
    return type_annotation(value)


def _convert_int(name: str, type_annotation: type[int], value: str) -> int:
    try:
        return type_annotation(int(value))
    except ValueError as e:
        raise _invalid_value(name, "int", value) from e


def _convert_float(name: str, type_annotation: type[float], value: str) -> float:
    try:
        return type_annotation(float(value))
    except ValueError as e:
        raise _invalid_value(name, "float", value) from e


def _convert_bool(name: str, type_annotation: type[bool], value: str) -> bool:
    if value not in ["true", "false"]:
        raise _invalid_value(name, "boolean", value)
    return type_annotation(value == "true")


# list/dict have no dedicated frontend widget, so they are advertised as plain
# string fields  and the user supplies a JSON string.
def _convert_list(name: str, type_annotation: type[list], value: str) -> list:
    try:
        result = json.loads(value)
    except json.JSONDecodeError as e:
        raise _invalid_value(name, "list", value) from e
    if not isinstance(result, list):
        raise _invalid_value(name, "list", value)
    return type_annotation(result)


def _convert_dict(name: str, type_annotation: type[dict], value: str) -> dict:
    try:
        result = json.loads(value)
    except json.JSONDecodeError as e:
        raise _invalid_value(name, "dict", value) from e
    if not isinstance(result, dict):
        raise _invalid_value(name, "dict", value)
    return type_annotation(result)


def _convert_collection(name: str, annotation: ParameterAnnotation, value: str) -> object:
    container, item_type = cast(type, get_origin(annotation)), get_args(annotation)[-1]
    kind = container.__name__
    if value == "":
        return container()
    try:
        parsed = json.loads(value, object_pairs_hook=_unique_keys_object(name, value) if container is dict else None)
    except json.JSONDecodeError as e:
        raise _invalid_value(name, kind, value) from e

    if container is dict:
        if not isinstance(parsed, dict):
            raise _invalid_value(name, kind, value)
        return {key: _convert_item(name, item_type, item, f"at key '{key}'") for key, item in parsed.items()}

    if not isinstance(parsed, list):
        raise _invalid_value(name, kind, value)
    items = [_convert_item(name, item_type, item, f"at index {index}") for index, item in enumerate(parsed)]
    if container is list:
        return items
    result = set(items)
    # Collapsing duplicates would silently change the configured set.
    if len(result) != len(items):
        raise ValueError(f"Parameter {name}: set value '{value}' contains duplicate items")
    return result


def _unique_keys_object(name: str, value: str) -> Callable[[list[tuple[str, object]]], dict]:
    # Dropping a repeated key would silently change the configured dict.
    def build(pairs: list[tuple[str, object]]) -> dict:
        result: dict = {}
        for key, item in pairs:
            if key in result:
                raise ValueError(f"Parameter {name}: dict value '{value}' contains duplicate key '{key}'")
            result[key] = item
        return result

    return build


def _convert_item(name: str, item_type: type, item: object, location: str) -> object:
    if issubclass(item_type, Enum):
        member = item_type.__members__.get(item) if isinstance(item, str) else None
        if member is None:
            raise _invalid_item(name, item_type, item, location)
        return member
    if item_type is float:
        if isinstance(item, (int, float)) and not isinstance(item, bool):
            return float(item)
    elif item_type is int:
        if isinstance(item, int) and not isinstance(item, bool):
            return item
    elif isinstance(item, item_type):
        return item
    raise _invalid_item(name, item_type, item, location)


def _invalid_item(name: str, item_type: type, item: object, location: str) -> ValueError:
    return ValueError(f"Parameter {name}: invalid {item_type.__name__} item value '{item}' {location}")


def _invalid_value(name: str, kind: str, value: object) -> ValueError:
    return ValueError(f"Parameter {name}: invalid {kind} value '{value}'")


_CONVERTERS: dict[type, Callable[[str, type, str], object]] = {
    HttpUcConnectionParameter: _convert_str,
    TextAreaParameter: _convert_str,
    Enum: _convert_enum,
    bool: _convert_bool,
    str: _convert_str,
    int: _convert_int,
    float: _convert_float,
    list: _convert_list,
    dict: _convert_dict,
}
