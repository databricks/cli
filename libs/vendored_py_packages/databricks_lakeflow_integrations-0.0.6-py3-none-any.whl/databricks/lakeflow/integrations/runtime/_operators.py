import sys

from databricks.lakeflow.integrations.runtime._invocation import invoke
from databricks.lakeflow.integrations.runtime._results import (
    ClosableState,
    Outcome,
    PythonOperatorClientMessage,
    completed_message,
    validate_poll_result_and_get_deferred_millis,
)
from databricks.lakeflow.integrations.runtime._tracebacks import user_traceback_lines
from databricks.lakeflow.integrations.shared._api import Context, Operator


def run_operator(
    obj: object,
    parameters: dict[str, str],
    context: Context,
    closable_state: ClosableState | None,
) -> PythonOperatorClientMessage:
    if closable_state not in (
        ClosableState.OPENING,
        ClosableState.OPENED,
        ClosableState.CLOSING,
        ClosableState.CLOSED,
    ):
        state = closable_state.name if closable_state is not None else None
        raise ValueError(f"Operator lifecycle state is missing or invalid: {state!r}")
    try:
        instance = invoke(obj, parameters)
    except Exception as error:
        if closable_state is ClosableState.OPENING:
            return completed_message(ClosableState.INIT_FAILED, error=error)
        raise
    return _run_operator_lifecycle(instance, context, closable_state)


def _run_operator_lifecycle(
    instance: Operator, context: Context, closable_state: ClosableState
) -> PythonOperatorClientMessage:
    has_close = type(instance).close is not Operator.close
    # Without a close override, CLOSED only means no cleanup is owed, not that
    # polling shouldn't continue.
    if closable_state is ClosableState.CLOSED and has_close:
        raise ValueError("Operator with close cannot poll after it has closed")
    if closable_state is ClosableState.CLOSING:
        return _close_operator(instance, context)

    try:
        if closable_state is ClosableState.OPENING:
            instance.open(context)
        result = instance.poll(context)
        deferred_duration_millis = validate_poll_result_and_get_deferred_millis(result)
    except Exception as error:
        return _close_operator(instance, context, work_error=error)

    if result.status == "deferred":
        return PythonOperatorClientMessage(
            outcome=Outcome.DEFERRED,
            deferred_duration_millis=deferred_duration_millis,
            closable_state=ClosableState.OPENED if has_close else ClosableState.CLOSED,
        )
    return _close_operator(instance, context)


def _close_operator(
    instance: Operator,
    context: Context,
    work_error: Exception | None = None,
) -> PythonOperatorClientMessage:
    try:
        instance.close(context)
    except Exception as error:
        if work_error is not None:
            print("\n".join(user_traceback_lines(error)), file=sys.stderr)
        return completed_message(ClosableState.CLOSE_FAILED, error=work_error if work_error is not None else error)
    return completed_message(ClosableState.CLOSED, error=work_error)
