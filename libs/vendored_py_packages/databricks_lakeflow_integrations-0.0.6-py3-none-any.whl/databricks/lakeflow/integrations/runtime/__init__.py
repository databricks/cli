import importlib
import inspect

from databricks.lakeflow.integrations.runtime._functions import run_function
from databricks.lakeflow.integrations.runtime._operators import run_operator
from databricks.lakeflow.integrations.runtime._results import (
    ClosableState,
    IntegrationKind,
    completed_message,
)
from databricks.lakeflow.integrations.runtime._sensors import run_sensor
from databricks.lakeflow.integrations.runtime._tracebacks import render_user_frames_only
from databricks.lakeflow.integrations.shared._api import Context, Operator, PollResult, Sensor, SensorResult

__all__ = [
    "Context",
    "Operator",
    "PollResult",
    "Sensor",
    "SensorResult",
    "_run_entrypoint",
]


def _run_entrypoint(bindings: dict[str, str], ctx: dict):
    try:
        return _try_run_entrypoint(bindings, ctx)
    except Exception as error:
        render_user_frames_only(error)
        raise


def _try_run_entrypoint(bindings: dict[str, str], ctx: dict):
    context = _parse_context(ctx)
    closable_state = _parse_closable_state(ctx)
    main = context.main

    parameters = {k: v for k, v in bindings.items() if not k.startswith("__databricks")}

    try:
        if "." not in main:
            raise ValueError("main is not a valid qualified name")

        module_name, func_name = main.rsplit(".", 1)

        if not module_name or not func_name:
            raise ValueError("main is not a valid qualified name")

        module = importlib.import_module(module_name)
        obj = getattr(module, func_name, None)

        if obj is None:
            raise ValueError(f"Function {func_name} not found in module {module_name}")
    except Exception as error:
        if closable_state is ClosableState.OPENING:
            return completed_message(ClosableState.INIT_FAILED, error=error)
        raise

    if inspect.isfunction(obj):
        integration_kind = IntegrationKind.FUNCTION
        report = run_function(obj, parameters, closable_state)
    elif _is_operator_class(obj):
        integration_kind = IntegrationKind.OPERATOR
        report = run_operator(obj, parameters, context, closable_state)
    elif _is_sensor_class(obj):
        integration_kind = IntegrationKind.SENSOR
        report = run_sensor(obj, parameters, context, closable_state)
    else:
        raise ValueError(f"{func_name} is not a function, Sensor, or Operator")

    report.payload["integration_kind"] = integration_kind.name
    return report


def _parse_closable_state(ctx: dict) -> ClosableState | None:
    raw = ctx.get("closable_state")
    if raw is None:
        return None
    try:
        return ClosableState[raw]
    except KeyError as error:
        raise ValueError(f"Unknown operator lifecycle state: {raw}") from error


def _parse_context(ctx: dict) -> Context:
    return Context(
        main=ctx["main"],
        task_key=ctx["task_key"],
        job_run_id=ctx["job_run_id"],
        task_run_id=ctx["task_run_id"],
        job_id=ctx["job_id"],
    )


def _is_sensor_class(obj: object) -> bool:
    return inspect.isclass(obj) and issubclass(obj, Sensor)


def _is_operator_class(obj: object) -> bool:
    return inspect.isclass(obj) and issubclass(obj, Operator)
