from databricks.lakeflow.integrations.runtime._invocation import invoke
from databricks.lakeflow.integrations.runtime._results import (
    ClosableState,
    PythonOperatorClientMessage,
    client_message_from_result,
    completed_message,
    validate_poll_result_and_get_deferred_millis,
)
from databricks.lakeflow.integrations.shared._api import Context, Sensor


def run_sensor(
    obj: object,
    parameters: dict[str, str],
    context: Context,
    closable_state: ClosableState | None,
) -> PythonOperatorClientMessage:
    if closable_state is ClosableState.CLOSING:
        return completed_message(ClosableState.CLOSED)
    try:
        instance = invoke(obj, parameters)

        if not isinstance(instance, Sensor):
            func_name = context.main.rsplit(".", 1)[-1]
            raise ValueError(f"{func_name} is not a Sensor")

        result = instance.poll(context)
        deferred_duration_millis = validate_poll_result_and_get_deferred_millis(result)
    except Exception as error:
        if closable_state is ClosableState.OPENING:
            return completed_message(ClosableState.CLOSED, error=error)
        raise

    return client_message_from_result(
        result,
        deferred_duration_millis=deferred_duration_millis,
        closable_state=ClosableState.CLOSED if closable_state is not None else None,
    )
