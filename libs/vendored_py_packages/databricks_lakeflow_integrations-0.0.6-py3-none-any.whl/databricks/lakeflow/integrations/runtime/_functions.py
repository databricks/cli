from databricks.lakeflow.integrations.runtime._invocation import invoke
from databricks.lakeflow.integrations.runtime._results import (
    ClosableState,
    PythonOperatorClientMessage,
    completed_message,
)


def run_function(
    obj: object,
    parameters: dict[str, str],
    closable_state: ClosableState | None,
) -> PythonOperatorClientMessage:
    if closable_state is ClosableState.CLOSING:
        return completed_message(ClosableState.CLOSED)
    try:
        invoke(obj, parameters)
    except Exception as error:
        if closable_state is ClosableState.OPENING:
            return completed_message(ClosableState.CLOSED, error=error)
        raise

    return completed_message(ClosableState.CLOSED if closable_state is not None else None)
