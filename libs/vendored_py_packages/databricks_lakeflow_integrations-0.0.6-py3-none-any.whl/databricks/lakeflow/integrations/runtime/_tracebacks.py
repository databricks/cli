import os
import traceback

_INTEGRATIONS_PACKAGE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + os.sep


def render_user_frames_only(error: BaseException) -> None:
    object.__setattr__(error, "_render_traceback_", lambda: user_traceback_lines(error))


def user_traceback_lines(error: BaseException) -> list[str]:
    summary = traceback.TracebackException.from_exception(error)
    for exception in _exception_chain(summary):
        exception.stack = _user_frames(exception.stack)
    return "".join(summary.format()).splitlines()


def _exception_chain(summary: traceback.TracebackException) -> list[traceback.TracebackException]:
    chain = []
    pending = [summary]
    while pending:
        exception = pending.pop()
        chain.append(exception)
        pending += [linked for linked in (exception.__cause__, exception.__context__) if linked is not None]
    return chain


def _user_frames(stack: traceback.StackSummary) -> traceback.StackSummary:
    reached_runtime = False
    user_frames = []
    for frame in stack:
        if user_frames or (reached_runtime and not _is_runtime_frame(frame)):
            user_frames.append(frame)
        elif _is_runtime_frame(frame):
            reached_runtime = True
    return traceback.StackSummary.from_list(user_frames) if reached_runtime else stack


def _is_runtime_frame(frame: traceback.FrameSummary) -> bool:
    return frame.filename.startswith(_INTEGRATIONS_PACKAGE_DIR)
