"""Parameter-type contract shared by the runtime binder and the definition generator.

The generator and the runtime binder live in separate modules that must not
import each other. Supported types and subclass precedence are shared here.
"""

from enum import Enum
from types import UnionType
from typing import TypeAlias, Union, get_args, get_origin

from databricks.lakeflow.integrations.shared._parameters import HttpUcConnectionParameter, TextAreaParameter

# A parameter's resolved annotation. Usually a plain type (int, str, list), but also a
# union form (Optional[int], int | None) or the inspect.Parameter.empty sentinel for an
# unannotated parameter, neither of which is a `type` instance.
ParameterAnnotation: TypeAlias = object

# The parameter types the operator can bind, mapped to the JSON Schema type the
# generator advertises. The generator reads this to build the config schema, and the
# runtime keys its converter table on the same types.
#
# list and dict have no dedicated widget, so they are advertised as "string"
# and the user pastes a JSON string that the binder parses.
# Order defines precedence: markers and enums precede their builtin bases,
# and bool precedes int.
_SUPPORTED_PARAM_TYPES: dict[type, str] = {
    HttpUcConnectionParameter: "string",
    TextAreaParameter: "string",
    Enum: "string",
    bool: "boolean",
    str: "string",
    int: "integer",
    float: "number",
    list: "string",
    dict: "string",
}


def _supported_parameter_type(annotation: ParameterAnnotation) -> type | None:
    if not isinstance(annotation, type):
        return None

    for supported_type in _SUPPORTED_PARAM_TYPES:
        if issubclass(annotation, supported_type):
            return supported_type

    return None


def _unwrap_optional(annotation: ParameterAnnotation) -> ParameterAnnotation:
    """Unwrap ``Optional[T]`` to its single non-None arm.

    Integration entry-point signatures are authored by the developer, so a
    parameter can be annotated ``Optional[int]`` / ``int | None`` (an optional
    widget with no default), and binds like its underlying ``T``. Matches the
    ``typing`` spelling (``Optional[T]``, ``Union[T, None]``) and PEP 604
    ``T | None``, which ``get_type_hints`` preserves as a ``types.UnionType``.
    """
    if get_origin(annotation) in (Union, UnionType):
        args = [arg for arg in get_args(annotation) if arg is not type(None)]
        if len(args) == 1:
            return args[0]
    return annotation


_SUPPORTED_ITEM_TYPES = frozenset({str, int, float, bool})

_SUPPORTED_TYPES_DESCRIPTION = (
    "only str, int, float, bool, list, dict, enums, and list[T], set[T], or dict[str, T] "
    "with T one of str, int, float, bool, or an enum are supported."
)


def _is_supported_item_type(annotation: ParameterAnnotation) -> bool:
    if annotation in _SUPPORTED_ITEM_TYPES:
        return True
    return isinstance(annotation, type) and issubclass(annotation, Enum)


def _is_collection_annotation(annotation: ParameterAnnotation) -> bool:
    """Whether ``annotation`` is a supported ``list[T]``, ``set[T]``, or ``dict[str, T]``."""
    origin, args = get_origin(annotation), get_args(annotation)
    if origin in (list, set):
        return len(args) == 1 and _is_supported_item_type(args[0])
    if origin is dict:
        return len(args) == 2 and args[0] is str and _is_supported_item_type(args[1])
    return False
