from dataclasses import dataclass


class HttpUcConnectionParameter(str):
    """The name of a UC HTTP connection."""


class TextAreaParameter(str):
    """A multiline string, edited in a textarea."""


@dataclass(frozen=True, kw_only=True)
class HttpConnectionFilter:
    """Optional exact-match filters for the UC HTTP connection picker."""

    host: str | None = None
    base_path: str | None = None

    def __post_init__(self) -> None:
        if self.host is not None and (not isinstance(self.host, str) or not self.host):
            raise ValueError("HttpConnectionFilter host must be a non-empty string")
        if self.base_path is not None and (not isinstance(self.base_path, str) or not self.base_path):
            raise ValueError("HttpConnectionFilter base_path must be a non-empty string")


@dataclass(frozen=True, kw_only=True)
class ParameterMetadata:
    """Metadata for an integration parameter.

    Attributes:
        display_name: Label shown for the parameter in the task editor. Defaults to the parameter name.
        description: Info tooltip text shown next to the label.
    """

    display_name: str | None = None
    description: str | None = None

    def __post_init__(self) -> None:
        if self.display_name is not None and (not isinstance(self.display_name, str) or not self.display_name):
            raise ValueError("ParameterMetadata display_name must be a non-empty string")
        if self.description is not None and (not isinstance(self.description, str) or not self.description):
            raise ValueError("ParameterMetadata description must be a non-empty string")
