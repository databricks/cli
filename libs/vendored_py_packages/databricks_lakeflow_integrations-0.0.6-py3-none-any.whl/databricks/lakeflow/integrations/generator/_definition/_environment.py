from typing import Optional


def build_environment(
    dependencies: list[str],
    environment_version: str,
    environment_key: Optional[str],
) -> dict:
    """Build the shared ``environment`` block.

    Example:

    ```json
    {
      "environment_key": "sample-environment-key",
      "environment_version": "5",
      "dependencies": [
        "cowsay",
        "pytest"
      ]
    }
    ```
    """
    if not dependencies:
        raise ValueError("environment requires at least one --dependency (must include the wheel that provides main)")

    environment: dict = {}
    if environment_key is not None:
        environment["environment_key"] = environment_key
    environment["environment_version"] = environment_version
    environment["dependencies"] = dependencies
    return environment
