import inspect
from collections.abc import Callable
from typing import Optional, Union

from databricks.lakeflow.integrations.generator._definition._config import build_config
from databricks.lakeflow.integrations.generator._definition._environment import build_environment
from databricks.lakeflow.integrations.shared._integration import get_integration_metadata

_SCHEMA_VERSION = "lakeflow-integration-v0.1.0"

_EntryPoint = Union[type, Callable]


def build_definitions(
    entry_points: list[_EntryPoint],
    dependencies: list[str],
    environment_version: str,
    environment_key: Optional[str],
) -> list[dict]:
    environment = build_environment(dependencies, environment_version, environment_key)
    return [_build_definition(obj, environment) for obj in entry_points]


def _build_definition(obj: _EntryPoint, environment: dict) -> dict:
    metadata = get_integration_metadata(obj)
    if metadata is None:
        raise ValueError(f"{obj.__module__}.{obj.__qualname__} is not an @integration entry point")

    definition = {
        "schema": _SCHEMA_VERSION,
        "name": metadata.display_name,
        "description": metadata.description or _docstring(obj) or metadata.display_name,
        "main": f"{obj.__module__}.{obj.__qualname__}",
        "config": build_config(obj),
    }
    if metadata.icon is not None:
        definition["icon"] = {"name": metadata.icon, "library": "databricks"}
    if metadata.promoted_parameter is not None:
        definition["promoted_parameter"] = metadata.promoted_parameter
    definition["environment"] = environment
    return definition


def _docstring(obj: _EntryPoint) -> Optional[str]:
    # __doc__ directly, not inspect.getdoc, which would inherit the
    # integration's protocol's docstring for an undocumented sensor.
    doc = obj.__doc__
    if doc:
        for line in inspect.cleandoc(doc).splitlines():
            stripped = line.strip()
            if stripped:
                return stripped
    return None
