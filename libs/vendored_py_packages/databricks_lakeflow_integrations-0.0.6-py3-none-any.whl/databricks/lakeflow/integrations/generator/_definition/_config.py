import inspect
import json
import math
from collections.abc import Callable, Iterable, Mapping
from enum import Enum
from typing import Annotated, Optional, Union, get_args, get_origin, get_type_hints

from databricks.lakeflow.integrations.shared._integration import get_integration_metadata
from databricks.lakeflow.integrations.shared._parameters import (
    HttpConnectionFilter,
    HttpUcConnectionParameter,
    ParameterMetadata,
    TextAreaParameter,
)
from databricks.lakeflow.integrations.generator._definition._ui import widget_ui
from databricks.lakeflow.integrations.shared._paramtypes import (
    _SUPPORTED_PARAM_TYPES,
    _SUPPORTED_TYPES_DESCRIPTION,
    _is_collection_annotation,
    _supported_parameter_type,
    _unwrap_optional,
)

_EntryPoint = Union[type, Callable]

# Parameter kinds that cannot be surfaced as named config fields: *args and
# **kwargs have no stable name to bind a widget to, and positional-only params
# cannot be passed by keyword (which is how the operator injects values).
_UNSUPPORTED_PARAMETER_KINDS = frozenset(
    {
        inspect.Parameter.VAR_POSITIONAL,
        inspect.Parameter.VAR_KEYWORD,
        inspect.Parameter.POSITIONAL_ONLY,
    }
)


def build_config(obj: _EntryPoint) -> dict:
    """Build the ``config`` JSON Schema from the entry point's signature.

    Example:

    ```json
    {
      "type": "object",
      "properties": {
        "table": {
          "type": "string"
        },
        "min_rows": {
          "type": "integer",
          "x-ui": {
            "widget": "number"
          },
          "default": 1
        },
        "freshness": {
          "type": "number",
          "x-ui": {
            "widget": "number"
          },
          "default": 0.5
        },
        "include_late": {
          "type": "boolean",
          "x-ui": {
            "widget": "toggle"
          },
          "default": false
        }
      },
      "required": [
        "table"
      ]
    }
    ```
    """
    _reject_unbindable_positional_only(obj)

    metadata = get_integration_metadata(obj)
    parameter_metadata = metadata.parameters if metadata is not None else {}
    config_parameters = _config_parameters(obj)
    _reject_unknown_parameter_metadata(obj, parameter_metadata, config_parameters)

    properties: dict[str, dict] = {}
    required: list[str] = []

    annotations = _annotations(obj)
    for param in config_parameters:
        annotation = annotations.get(param.name, param.annotation)
        prop = _config_property(param.name, annotation, parameter_metadata.get(param.name))
        annotation, _ = _resolve_parameter_annotation(annotation)

        if param.default is inspect.Parameter.empty:
            required.append(param.name)
        elif _is_collection_annotation(annotation):
            # None has no JSON form, so the field stays unset and the Python default applies.
            if param.default is not None:
                prop["default"] = json.dumps(_collection_default(param.name, annotation, param.default))
        elif isinstance(param.default, Enum):
            _reject_mismatched_enum_default(param.name, annotation, param.default)
            prop["default"] = (
                param.default.name if _supported_parameter_type(annotation) is Enum else param.default.value
            )
        elif _is_scalar(param.default):
            _reject_mismatched_default(param.name, annotation, param.default)
            prop["default"] = param.default

        properties[param.name] = prop

    if metadata is not None and metadata.promoted_parameter is not None:
        _reject_unpromotable_parameter(obj, metadata.promoted_parameter, config_parameters, annotations)

    config: dict = {"type": "object", "properties": properties}
    if required:
        config["required"] = required
    return config


def _reject_unbindable_positional_only(obj: _EntryPoint) -> None:
    for param in _signature_parameters(obj):
        if param.kind is inspect.Parameter.POSITIONAL_ONLY and param.default is inspect.Parameter.empty:
            raise ValueError(
                f"Parameter {param.name}: positional-only parameters cannot be bound "
                f"(the operator injects values by keyword); add a default or make it keyword-accessible."
            )


def _reject_unknown_parameter_metadata(
    obj: _EntryPoint,
    parameter_metadata: Mapping[str, ParameterMetadata],
    config_parameters: list[inspect.Parameter],
) -> None:
    names = [param.name for param in config_parameters]
    unknown = sorted(set(parameter_metadata) - set(names))
    if unknown:
        raise ValueError(
            f"{obj.__module__}.{obj.__qualname__}: @integration parameters {unknown} do not match "
            f"any configurable parameter; expected a subset of {names}."
        )


def _reject_unpromotable_parameter(
    obj: _EntryPoint,
    promoted_parameter: str,
    config_parameters: list[inspect.Parameter],
    annotations: dict,
) -> None:
    parameter_names = [param.name for param in config_parameters]
    if promoted_parameter not in parameter_names:
        raise ValueError(
            f"{obj.__module__}.{obj.__qualname__}: @integration promoted_parameter {promoted_parameter!r} does not "
            f"match any configurable parameter; expected one of {parameter_names}."
        )
    param = config_parameters[parameter_names.index(promoted_parameter)]
    annotation, _ = _resolve_parameter_annotation(annotations.get(param.name, param.annotation))
    if (get_origin(annotation) or annotation) in (list, set, dict) or (
        _supported_parameter_type(annotation) is TextAreaParameter
    ):
        raise ValueError(
            f"{obj.__module__}.{obj.__qualname__}: @integration promoted_parameter {promoted_parameter!r} cannot be "
            f"a textarea, list, set, or dict parameter."
        )


def _reject_mismatched_default(name: str, annotation: object, default: object) -> None:
    resolved = _unwrap_optional(annotation)
    if resolved is inspect.Parameter.empty:
        if not isinstance(default, str):
            raise ValueError(
                f"Parameter {name}: an unannotated parameter binds as a string, but its "
                f"default {default!r} is not a string; add a type annotation."
            )
        return

    if isinstance(resolved, type) and not _default_matches_type(default, resolved):
        raise ValueError(
            f"Parameter {name}: default {default!r} does not match the annotated type '{resolved.__name__}'."
        )


def _reject_mismatched_enum_default(name: str, annotation: object, default: object) -> None:
    resolved = _unwrap_optional(annotation)
    if resolved is inspect.Parameter.empty:
        raise ValueError(
            f"Parameter {name}: an unannotated parameter binds as a string, but its "
            f"default {default!r} is an enum member; annotate it with the enum type."
        )

    if isinstance(resolved, type) and not isinstance(default, resolved):
        raise ValueError(
            f"Parameter {name}: default {default!r} does not match the annotated type '{resolved.__name__}'."
        )


# Tuples and frozensets are accepted, since mutable defaults are a Python pitfall.
_DEFAULT_CONTAINERS: dict[object, tuple[type, ...]] = {list: (list, tuple), set: (set, frozenset)}


def _collection_default(name: str, annotation: object, default: object) -> object:
    container, item_type = get_origin(annotation), get_args(annotation)[-1]
    if container is dict and isinstance(default, dict) and all(isinstance(key, str) for key in default):
        _reject_mismatched_items(name, item_type, default.values())
        return {key: _default_json(value) for key, value in default.items()}
    if isinstance(default, (list, tuple, set, frozenset)) and isinstance(
        default, _DEFAULT_CONTAINERS.get(container, ())
    ):
        _reject_mismatched_items(name, item_type, default)
        if container is set and issubclass(item_type, Enum):
            return [member.name for member in item_type if member in default]
        return sorted(default) if container is set else [_default_json(item) for item in default]
    raise ValueError(f"Parameter {name}: default {default!r} does not match the annotated type '{annotation}'.")


def _reject_mismatched_items(name: str, item_type: type, items: Iterable[object]) -> None:
    for item in items:
        if isinstance(item, Enum):
            _reject_mismatched_enum_default(name, item_type, item)
        elif _is_scalar(item):
            _reject_mismatched_default(name, item_type, item)
        else:
            raise ValueError(
                f"Parameter {name}: default {item!r} does not match the annotated type '{item_type.__name__}'."
            )


def _default_json(default: object) -> object:
    return default.name if isinstance(default, Enum) else default


def _default_matches_type(default: object, resolved_type: type) -> bool:
    if resolved_type is bool:
        return isinstance(default, bool)
    if resolved_type is int:
        # note: bool is a subclass of int
        return isinstance(default, int) and not isinstance(default, bool)
    if resolved_type is float:
        return isinstance(default, (int, float)) and not isinstance(default, bool)
    return isinstance(default, resolved_type)


def _config_parameters(obj: _EntryPoint) -> list[inspect.Parameter]:
    return [param for param in _signature_parameters(obj) if param.kind not in _UNSUPPORTED_PARAMETER_KINDS]


def _signature_parameters(obj: _EntryPoint) -> list[inspect.Parameter]:
    try:
        signature = inspect.signature(obj)
    except (ValueError, TypeError):
        # Builtins and some C-level types have no introspectable signature.
        return []

    return list(signature.parameters.values())


def _annotations(obj: _EntryPoint) -> dict:
    # get_type_hints resolves deferred (PEP 563) / forward-reference annotations
    # against the module globals. For a class they live on __init__.
    target = obj.__init__ if inspect.isclass(obj) else obj
    return get_type_hints(target, include_extras=True)


def _config_property(name: str, annotation: object, parameter_metadata: Optional[ParameterMetadata] = None) -> dict:
    prop = _widget_property(name, annotation)
    if parameter_metadata is not None:
        prop["title"] = parameter_metadata.display_name or name
        if parameter_metadata.description is not None:
            prop["description"] = parameter_metadata.description
    return prop


def _widget_property(name: str, annotation: object) -> dict:
    annotation, connection_filters = _resolve_parameter_annotation(annotation)
    if annotation is inspect.Parameter.empty:
        annotation = str

    is_http_connection = _supported_parameter_type(annotation) is HttpUcConnectionParameter
    if is_http_connection and len(connection_filters) > 1:
        raise ValueError(f"Parameter {name}: only one HttpConnectionFilter is allowed")
    if not is_http_connection and len(connection_filters) > 0:
        raise ValueError(f"Parameter {name}: HttpConnectionFilter requires HttpUcConnectionParameter")

    schema_type = _schema_type(annotation)
    if schema_type is None:
        raise ValueError(f"Parameter {name}: unsupported type '{annotation}', {_SUPPORTED_TYPES_DESCRIPTION}")
    prop: dict = {"type": schema_type}
    ui = widget_ui(annotation, connection_filters)
    if ui is not None:
        prop["x-ui"] = ui
    return prop


def _schema_type(annotation: object) -> Optional[str]:
    origin = get_origin(annotation)
    if origin is not None and _is_collection_annotation(annotation):
        return origin.__name__
    parameter_type = _supported_parameter_type(annotation)
    return _SUPPORTED_PARAM_TYPES[parameter_type] if parameter_type is not None else None


def _resolve_parameter_annotation(annotation: object) -> tuple[object, list[HttpConnectionFilter]]:
    """Unwrap Annotated/Optional layers to the underlying type, collecting any HttpConnectionFilter metadata."""
    if get_origin(annotation) is Annotated:
        inner, *metadata = get_args(annotation)
        resolved, filters = _resolve_parameter_annotation(inner)
        return resolved, filters + [value for value in metadata if isinstance(value, HttpConnectionFilter)]
    resolved = _unwrap_optional(annotation)
    if resolved is not annotation:
        return _resolve_parameter_annotation(resolved)
    return annotation, []


def _is_scalar(value: object) -> bool:
    if isinstance(value, float):
        # exclude NaN / inf as they're not valid JSON or YAML
        return math.isfinite(value)
    return isinstance(value, (str, int, bool))
