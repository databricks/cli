"""Build the ``x-ui`` object that picks the console widget for a config field."""

from collections.abc import Sequence
from enum import Enum
from typing import Optional, cast, get_args, get_origin

from databricks.lakeflow.integrations.shared._parameters import (
    HttpConnectionFilter,
    HttpUcConnectionParameter,
    TextAreaParameter,
)
from databricks.lakeflow.integrations.shared._paramtypes import _is_collection_annotation, _supported_parameter_type

_COLLECTION_WIDGETS: dict[object, str] = {list: "list", set: "set", dict: "keyvalue"}


def widget_ui(annotation: object, connection_filters: Sequence[HttpConnectionFilter] = ()) -> Optional[dict]:
    """The ``x-ui`` for a resolved annotation, or ``None`` for the default single-line input."""
    parameter_type = _supported_parameter_type(annotation)
    if parameter_type is HttpUcConnectionParameter:
        return _http_connection_ui(connection_filters)
    if parameter_type is TextAreaParameter:
        return {"widget": "textarea"}
    if parameter_type is Enum:
        return {
            "widget": "select",
            "optionsSource": {"type": "static", "values": [member.name for member in cast(type[Enum], annotation)]},
        }
    if parameter_type is bool:
        return {"widget": "toggle"}
    if parameter_type in (int, float):
        return {"widget": "number"}
    if _is_collection_annotation(annotation):
        ui: dict = {"widget": _COLLECTION_WIDGETS[get_origin(annotation)]}
        item_ui = widget_ui(get_args(annotation)[-1])
        if item_ui is not None:
            ui["item"] = item_ui
        return ui
    return None


def _http_connection_ui(connection_filters: Sequence[HttpConnectionFilter]) -> dict:
    ui = {"widget": "select_uc_connection", "connection_type": "HTTP"}
    if connection_filters:
        connection_filter = connection_filters[0]
        for key, value in (("host", connection_filter.host), ("base_path", connection_filter.base_path)):
            if value is not None:
                ui[key] = value
    return ui
