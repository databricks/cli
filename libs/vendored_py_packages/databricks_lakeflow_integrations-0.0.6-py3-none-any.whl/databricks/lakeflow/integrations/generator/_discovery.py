import importlib
import inspect
import pkgutil
from collections.abc import Callable
from types import ModuleType
from typing import Union

from databricks.lakeflow.integrations.shared._integration import get_integration_metadata

_EntryPoint = Union[type, Callable]


def discover_entry_points(package_module_name: str) -> list[_EntryPoint]:
    """Import the package recursively and collect its ``@integration`` entry points.

    Results are deduplicated by entry point name and sorted by it.
    """
    package = importlib.import_module(package_module_name)

    entry_points: dict[str, _EntryPoint] = {}
    for module in _load_modules(package):
        for _name, member in inspect.getmembers(module):
            if _is_entry_point(member, module.__name__):
                entry_points[f"{member.__module__}.{member.__qualname__}"] = member

    return [entry_points[main] for main in sorted(entry_points)]


def _load_modules(package_module: ModuleType) -> list[ModuleType]:
    spec = package_module.__spec__
    if spec is None:
        raise ValueError(f"Module '{package_module.__name__}' has no __spec__")

    module_names = []
    # A package with an __init__.py has an origin. A namespace package does not.
    if spec.origin:
        module_names.append(spec.name)

    if spec.submodule_search_locations:
        prefix = spec.name + "."
        for _finder, name, _is_pkg in pkgutil.walk_packages(spec.submodule_search_locations, prefix):
            module_names.append(name)

    # Sort for a deterministic import order.
    return [importlib.import_module(name) for name in sorted(set(module_names))]


def _is_entry_point(obj: object, module_name: str) -> bool:
    # Restrict to entry points physically defined in this module so one
    # imported into another module is not reported twice.
    if getattr(obj, "__module__", None) != module_name:
        return False
    return get_integration_metadata(obj) is not None
