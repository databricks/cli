import argparse
from pathlib import Path
from typing import Optional

from databricks.lakeflow.integrations.generator._definition import build_definitions
from databricks.lakeflow.integrations.generator._discovery import discover_entry_points
from databricks.lakeflow.integrations.generator._write import write_definitions


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--package-module",
        required=True,
        help="Dotted name of the package to load recursively, e.g. 'my_pkg'.",
    )
    parser.add_argument(
        "--output-dir",
        required=True,
        help="Directory to write one '<main>.yml' file per sensor into.",
    )
    parser.add_argument(
        "--dependency",
        action="append",
        default=[],
        dest="dependencies",
        required=True,
        metavar="SPEC",
        help="pip-style dependency or workspace .whl path for the environment "
        "block. Repeatable; must include the wheel that provides the entry points.",
    )
    parser.add_argument(
        "--environment-version",
        required=True,
        help="environment_version for the environment block, e.g. '5'.",
    )
    parser.add_argument(
        "--environment-key",
        help="environment_key for the environment block.",
    )
    args = parser.parse_args(argv)

    definitions = _generate(
        package_module_name=args.package_module,
        dependencies=args.dependencies,
        environment_version=args.environment_version,
        environment_key=args.environment_key,
    )
    write_definitions(definitions, Path(args.output_dir))


def _generate(
    package_module_name: str,
    dependencies: list[str],
    environment_version: str,
    environment_key: Optional[str],
) -> list[dict]:
    """Return integration definitions sorted by their entry-point names."""
    return build_definitions(
        discover_entry_points(package_module_name), dependencies, environment_version, environment_key
    )


if __name__ == "__main__":
    main()
