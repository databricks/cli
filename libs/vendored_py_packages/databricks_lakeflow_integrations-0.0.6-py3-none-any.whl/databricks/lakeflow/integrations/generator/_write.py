import json
from pathlib import Path


def write_definitions(
    definitions: list[dict],
    output_dir: Path,
) -> list[Path]:
    """Write one ``<main>.yml`` file per entry point into ``output_dir``."""

    output_dir.mkdir(parents=True, exist_ok=True)

    written = []
    for definition in definitions:
        path = output_dir / f"{definition['main']}.yml"
        path.write_text(json.dumps(definition, indent=2) + "\n")
        written.append(path)

    _prune_stale_definitions(output_dir, keep=written)

    return sorted(written)


def _prune_stale_definitions(output_dir: Path, keep: list[Path]) -> None:
    current = set(keep)
    for existing in output_dir.glob("*.yml"):
        if existing not in current:
            existing.unlink()
